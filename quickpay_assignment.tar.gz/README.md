# QuickPay Data Analyst Assignment

## Student Details

- **Name**: [Your Name]
- **Student ID**: [Your ID]
- **GitHub Repository**: [Your Repo Link]

## Overview

This repository contains the complete data analysis assignment for QuickPay, covering transaction data cleaning, SQL-based business analysis, a Python reconciliation workflow, JSON normalization, and a dashboard for business monitoring.

## How to Run

1. Make sure the raw data files are placed in `01_data/raw/`.
2. Open `04_python/fintech_pipeline.ipynb` in Jupyter and run all cells. The notebook reads from `01_data/raw/` and writes outputs to `01_data/processed/` and `04_python/`.
3. SQL queries in `03_sql/analysis_queries.sql` can be run against the `cleaned_transactions.csv` loaded into any SQL engine (SQLite, PostgreSQL, etc.).
4. The spreadsheet workbook is at `02_spreadsheet/spreadsheet_workbook.xlsx`.
5. Dashboard link is in `05_visualization/dashboard_link.txt`.

## Tools Used

- **Python 3.12** with pandas, numpy, openpyxl
- **Jupyter Notebook** for the reconciliation pipeline and JSON normalization
- **SQLite** for validating SQL queries
- **Excel / openpyxl** for the spreadsheet workbook
- **Looker Studio** for the dashboard

## Repository Structure

```
├── README.md
├── 01_data/
│   ├── raw/           (7 input files)
│   └── processed/     (12 output CSVs)
├── 02_spreadsheet/
│   ├── spreadsheet_workbook.xlsx
│   └── spreadsheet_answers.md
├── 03_sql/
│   ├── analysis_queries.sql
│   └── sql_answers.md
├── 04_python/
│   ├── fintech_pipeline.ipynb
│   └── summary_metrics.json
└── 05_visualization/
    └── dashboard_link.txt
```
